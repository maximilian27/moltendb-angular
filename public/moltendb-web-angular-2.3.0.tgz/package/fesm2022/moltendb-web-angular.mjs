import * as i0 from '@angular/core';
import { InjectionToken, makeEnvironmentProviders, signal, inject, PLATFORM_ID, Injectable, untracked, effect, DestroyRef } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { MoltenDb } from '@moltendb-web/core';
import { MoltenDbClient } from '@moltendb-web/query';

const MOLTEN_CONFIG = new InjectionToken("MOLTEN_CONFIG");
function provideMoltenDb(config) {
    return makeEnvironmentProviders([
        { provide: MOLTEN_CONFIG, useValue: config },
    ]);
}

/**
 * Thrown by the server-side stubs whenever code tries to actually reach the
 * MoltenDb engine while running outside the browser (SSR / prerendering).
 */
const MOLTEN_SSR_ERROR_MESSAGE = "[MoltenDb] MoltenDb is not available in a server-side rendering context.";
/**
 * Stand-in for `MoltenDb` used when running outside the browser (SSR / prerendering).
 * It never touches WASM, OPFS, or the Web Locks API. `init()` resolves immediately
 * and `clearOpfs()` is a no-op — there is nothing to boot or clear on the server.
 */
class ServerMoltenDb extends MoltenDb {
    init() {
        return Promise.resolve();
    }
    sendMessage() {
        return Promise.reject(new Error(MOLTEN_SSR_ERROR_MESSAGE));
    }
    async clearOpfs() {
        // No OPFS storage exists on the server — nothing to clear.
    }
}
/**
 * Stand-in transport used when running outside the browser (SSR / prerendering).
 * Query builder chains (`.collection().set()`, `.get()`, `.delete()`, ...) keep
 * working synchronously — only the terminal `.exec()` call rejects, with a clear,
 * actionable error instead of hanging forever.
 */
class ServerTransport {
    sendMessage() {
        return Promise.reject(new Error(MOLTEN_SSR_ERROR_MESSAGE));
    }
}
class MoltenDbService {
    db;
    client;
    // Internal signal used by `moltenDbResource()` to know when WASM is booted and
    // Leader Election is done. @internal — not part of the public API: `MoltenDbService`
    // itself is never re-exported from `public-api.ts`, and no getter or standalone
    // `moltenDbReady()`-style function should ever be added to expose this signal.
    // Stays `false` forever on the server, which is what makes `moltenDbResource()`
    // skip fetching there with no changes needed on its "don't fetch" path.
    isReady = signal(false);
    constructor() {
        const config = inject(MOLTEN_CONFIG);
        const isBrowser = isPlatformBrowser(inject(PLATFORM_ID));
        if (!isBrowser) {
            // Server: never construct the real engine — no WASM, no OPFS, no Web Locks.
            this.db = new ServerMoltenDb(config.name, config);
            this.client = new MoltenDbClient(new ServerTransport());
            return;
        }
        this.db = new MoltenDb(config.name, config);
        this.client = new MoltenDbClient(this.db);
        // Boot the engine and update the signal when done
        this.db
            .init()
            .then(() => {
            this.isReady.set(true);
        })
            .catch((err) => {
            console.error("[MoltenDb] Failed to initialize", err);
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MoltenDbService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MoltenDbService, providedIn: "root" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MoltenDbService, decorators: [{
            type: Injectable,
            args: [{ providedIn: "root" }]
        }], ctorParameters: () => [] });

function moltenDbResource(collection, 
//  Automatically infer the return type of .collection()
queryFn, options) {
    const molten = inject(MoltenDbService);
    const isBrowser = isPlatformBrowser(inject(PLATFORM_ID));
    const value = signal(options?.initialValue);
    const isLoading = signal(false);
    const error = signal(null);
    // Server (SSR/prerendering): MoltenDb never boots here, so resolve to an
    // explicit, documented empty state — `isLoading()` false, `error()` null,
    // `value()` at `options?.initialValue` (or `undefined` if none was given) —
    // synchronously, with no fetch attempted and no hang.
    if (!isBrowser) {
        return {
            value: value.asReadonly(),
            isLoading: isLoading.asReadonly(),
            error: error.asReadonly(),
        };
    }
    const fetchData = async () => {
        untracked(() => isLoading.set(true));
        try {
            // ⚡ Pre-bind the collection and pass it in!
            const result = await queryFn(molten.client.collection(collection), molten.client);
            value.set(result);
            error.set(null);
        }
        catch (err) {
            if (err.message?.includes("404")) {
                value.set([]);
                error.set(null);
            }
            else {
                error.set(err);
            }
        }
        finally {
            isLoading.set(false);
        }
    };
    effect((onCleanup) => {
        if (!molten.isReady())
            return;
        fetchData();
        const unsubscribe = molten.db.subscribe((evt) => {
            if (evt.collection === collection)
                fetchData();
        });
        onCleanup(() => unsubscribe());
    });
    return {
        value: value.asReadonly(),
        isLoading: isLoading.asReadonly(),
        error: error.asReadonly(),
    };
}

/** Functional injection hook to access the MoltenDb Query Client. */
function moltendbClient() {
    return inject(MoltenDbService).client;
}
/** Returns true if this tab is the Leader (running the WASM worker). */
function moltenDbIsLeader() {
    return inject(MoltenDbService).db.isLeader;
}
/**
 * Flushes and closes the OPFS sync handle.
 * Call this before `moltenDbTerminate()` to avoid "No modification allowed" errors.
 */
async function moltenDbClearOpfs() {
    await inject(MoltenDbService).db.clearOpfs();
}
/** Terminates the MoltenDb worker. Call after clearing OPFS storage. */
function moltenDbTerminate() {
    inject(MoltenDbService).db.terminate();
}
/**
 * Subscribe to real-time MoltenDb mutation events.
 * The subscription is automatically cleaned up when the injection context (component/service) is destroyed.
 * No manual unsubscription or ngOnDestroy needed.
 * Must be run in injection context (component/service).
 */
function moltenDbEvents(listener) {
    const unsub = inject(MoltenDbService).db.subscribe(listener);
    inject(DestroyRef).onDestroy(() => unsub());
}

/*
 * Public API Surface of @moltendb-web/angular
 */

/**
 * Generated bundle index. Do not edit.
 */

export { MOLTEN_CONFIG, moltenDbClearOpfs, moltenDbEvents, moltenDbIsLeader, moltenDbResource, moltenDbTerminate, moltendbClient, provideMoltenDb };
//# sourceMappingURL=moltendb-web-angular.mjs.map

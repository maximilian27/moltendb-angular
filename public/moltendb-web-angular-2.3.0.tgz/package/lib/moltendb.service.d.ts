import { MoltenDb } from "@moltendb-web/core";
import { MoltenDbClient } from "@moltendb-web/query";
import * as i0 from "@angular/core";
/**
 * Thrown by the server-side stubs whenever code tries to actually reach the
 * MoltenDb engine while running outside the browser (SSR / prerendering).
 */
export declare const MOLTEN_SSR_ERROR_MESSAGE = "[MoltenDb] MoltenDb is not available in a server-side rendering context.";
export declare class MoltenDbService {
    db: MoltenDb;
    client: MoltenDbClient;
    isReady: import("@angular/core").WritableSignal<boolean>;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<MoltenDbService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MoltenDbService>;
}

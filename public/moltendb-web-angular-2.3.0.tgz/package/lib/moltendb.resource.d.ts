import { Signal } from "@angular/core";
import { MoltenDbClient } from "@moltendb-web/query";
export interface MoltenDbResource<T> {
    value: Signal<T | undefined>;
    isLoading: Signal<boolean>;
    error: Signal<any | null>;
}
export interface MoltenDbResourceOptions<T> {
    /**
     * Value the `value` signal starts with, before the first fetch resolves in
     * the browser — and what it stays at (unchanged) on the server, since no
     * fetch is ever attempted there. Defaults to `undefined` when omitted.
     */
    initialValue?: T;
}
export declare function moltenDbResource<T>(collection: string, queryFn: (collection: ReturnType<MoltenDbClient["collection"]>, client: MoltenDbClient) => Promise<T>, options?: MoltenDbResourceOptions<T>): MoltenDbResource<T>;

import { Signal } from '@angular/core';
import { MoltenDBClient } from '@moltendb-web/query';
export interface MoltenDbResource<T> {
    /** The current data snapshot. Returns undefined while loading or on error. */
    value: Signal<T | undefined>;
    /** True if a fetch (initial or refresh) is currently in progress. */
    isLoading: Signal<boolean>;
    /** The error object if the last operation failed. */
    error: Signal<any | null>;
    /** Manually trigger a refresh. */
    reload: () => Promise<void>;
}
export declare function moltenDbResource<T>(collection: string, queryFn: (client: MoltenDBClient) => Promise<T>): MoltenDbResource<T>;

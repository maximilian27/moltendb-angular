import { MoltenDB } from '@moltendb-web/core';
import { MoltenDBClient } from '@moltendb-web/query';
import * as i0 from "@angular/core";
export declare class MoltenService {
    db: MoltenDB;
    client: MoltenDBClient;
    isReady: import("@angular/core").WritableSignal<boolean>;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<MoltenService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MoltenService>;
}

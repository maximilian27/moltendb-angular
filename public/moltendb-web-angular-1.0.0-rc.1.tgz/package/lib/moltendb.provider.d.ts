import { EnvironmentProviders, InjectionToken } from '@angular/core';
import { MoltenDBOptions } from '@moltendb-web/core';
export interface AngularMoltenOptions extends MoltenDBOptions {
    name: string;
}
export declare const MOLTEN_CONFIG: InjectionToken<AngularMoltenOptions>;
export declare function provideMoltenDB(config: AngularMoltenOptions): EnvironmentProviders;

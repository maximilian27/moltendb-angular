/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@moltendb-web/angular" />
export * from './public-api';

import * as i0 from '@angular/core';
import { InjectionToken, makeEnvironmentProviders, signal, inject, Injectable, untracked, effect } from '@angular/core';
import { MoltenDB } from '@moltendb-web/core';
import { MoltenDBClient } from '@moltendb-web/query';

const MOLTEN_CONFIG = new InjectionToken('MOLTEN_CONFIG');
function provideMoltenDB(config) {
    return makeEnvironmentProviders([
        { provide: MOLTEN_CONFIG, useValue: config }
    ]);
}

class MoltenService {
    db;
    client;
    // A Signal components can watch to know when WASM is booted and Leader Election is done
    isReady = signal(false);
    constructor() {
        // 🚀 Modern Angular Injection (No constructor decorators needed!)
        const config = inject(MOLTEN_CONFIG);
        this.db = new MoltenDB(config.name, config);
        this.client = new MoltenDBClient(this.db);
        // Boot the engine and update the signal when done
        this.db.init().then(() => {
            this.isReady.set(true);
        }).catch(err => {
            console.error('[MoltenDB] Failed to initialize', err);
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MoltenService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MoltenService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MoltenService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [] });

function moltenDbResource(collection, queryFn) {
    const molten = inject(MoltenService);
    const value = signal(undefined);
    const isLoading = signal(false);
    const error = signal(null);
    const fetchData = async () => {
        // ⚡ Break the dependency chain so the calling effect doesn't loop
        untracked(() => isLoading.set(true));
        try {
            const result = await queryFn(molten.client);
            value.set(result);
            error.set(null);
        }
        catch (err) {
            // Graceful 404 handling: if collection is missing, it's just empty data
            if (err.message?.includes('404')) {
                value.set([]);
                error.set(null);
            }
            else {
                error.set(err);
            }
        }
        finally {
            isLoading.set(false);
        }
    };
    effect((onCleanup) => {
        if (!molten.isReady())
            return;
        fetchData();
        // Auto-refresh when the underlying collection changes
        const unsubscribe = molten.db.subscribe((evt) => {
            if (evt.collection === collection)
                fetchData();
        });
        onCleanup(() => unsubscribe());
    });
    return {
        value: value.asReadonly(),
        isLoading: isLoading.asReadonly(),
        error: error.asReadonly(),
        reload: fetchData
    };
}

/*
 * Public API Surface of @moltendb-web/angular
 */

/**
 * Generated bundle index. Do not edit.
 */

export { MOLTEN_CONFIG, MoltenService, moltenDbResource, provideMoltenDB };
//# sourceMappingURL=moltendb-web-angular.mjs.map

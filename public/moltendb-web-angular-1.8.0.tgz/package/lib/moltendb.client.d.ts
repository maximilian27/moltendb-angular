import { MoltenDbClient } from "@moltendb-web/query";
import { DbEvent } from "@moltendb-web/core";
/** Functional injection hook to access the MoltenDb Query Client. */
export declare function moltendbClient(): MoltenDbClient;
/** Returns true once MoltenDb has finished initialising. */
export declare function moltenDbReady(): boolean;
/** Returns true if this tab is the Leader (running the WASM worker). */
export declare function moltenDbIsLeader(): boolean;
/** Terminates the MoltenDb worker. Call before clearing OPFS storage. */
export declare function moltenDbTerminate(): void;
/**
 * Flushes and closes the OPFS sync handle.
 * Call this before `moltenDbTerminate()` to avoid "No modification allowed" errors.
 */
export declare function moltenDbClearOpfs(): Promise<void>;
/**
 * Subscribe to real-time MoltenDb mutation events.
 * The subscription is automatically cleaned up when the injection context (component/service) is destroyed.
 * No manual unsubscription or ngOnDestroy needed.
 */
export declare function moltenDbEvents(listener: (event: DbEvent) => void): void;

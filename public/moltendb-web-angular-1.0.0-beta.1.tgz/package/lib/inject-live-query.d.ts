import { Signal } from '@angular/core';
import { MoltenDBClient } from '@moltendb-web/query';
export interface LiveQueryResult<T> {
    data: Signal<T | undefined>;
    isLoading: Signal<boolean>;
    error: Signal<Error | null>;
}
/**
 * A reactive hook that binds to MoltenDB.
 * Automatically handles loading states, real-time cross-tab updates, and memory cleanup.
 */
export declare function injectLiveQuery<T>(collection: string, queryFn: (client: MoltenDBClient) => Promise<T>): LiveQueryResult<T>;

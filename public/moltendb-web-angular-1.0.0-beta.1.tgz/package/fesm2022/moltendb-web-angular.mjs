import * as i0 from '@angular/core';
import { InjectionToken, makeEnvironmentProviders, signal, inject, Injectable, DestroyRef, effect } from '@angular/core';
import { MoltenDB } from '@moltendb-web/core';
import { MoltenDBClient } from '@moltendb-web/query';

const MOLTEN_CONFIG = new InjectionToken('MOLTEN_CONFIG');
function provideMoltenDB(config) {
    return makeEnvironmentProviders([
        { provide: MOLTEN_CONFIG, useValue: config }
    ]);
}

class MoltenService {
    db;
    client;
    // A Signal components can watch to know when WASM is booted and Leader Election is done
    isReady = signal(false);
    constructor() {
        // 🚀 Modern Angular Injection (No constructor decorators needed!)
        const config = inject(MOLTEN_CONFIG);
        this.db = new MoltenDB(config.name, config);
        this.client = new MoltenDBClient(this.db);
        // Boot the engine and update the signal when done
        this.db.init().then(() => {
            this.isReady.set(true);
        }).catch(err => {
            console.error('[MoltenDB] Failed to initialize', err);
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MoltenService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MoltenService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MoltenService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [] });

/**
 * A reactive hook that binds to MoltenDB.
 * Automatically handles loading states, real-time cross-tab updates, and memory cleanup.
 */
function injectLiveQuery(collection, queryFn) {
    const molten = inject(MoltenService);
    const destroyRef = inject(DestroyRef);
    const data = signal(undefined);
    const isLoading = signal(true);
    const error = signal(null);
    // effect() runs immediately, and re-runs if molten.isReady() changes state
    effect((onCleanup) => {
        if (!molten.isReady())
            return;
        // 1. Fetch logic
        const fetchData = async () => {
            isLoading.set(true);
            try {
                const result = await queryFn(molten.client);
                data.set(result);
                error.set(null);
            }
            catch (err) {
                error.set(err);
            }
            finally {
                isLoading.set(false);
            }
        };
        // 2. Fetch initial data snapshot
        fetchData();
        // 3. Subscribe to the real-time event stream
        const unsubscribe = molten.db.subscribe((evt) => {
            if (evt.collection === collection) {
                fetchData(); // Background re-fetch on mutation!
            }
        });
        // 4. Automatically clean up the listener when the effect is destroyed or component unmounts
        onCleanup(() => {
            unsubscribe();
        });
    });
    return { data, isLoading, error };
}

/*
 * Public API Surface of @moltendb-web/angular
 */

/**
 * Generated bundle index. Do not edit.
 */

export { MOLTEN_CONFIG, MoltenService, injectLiveQuery, provideMoltenDB };
//# sourceMappingURL=moltendb-web-angular.mjs.map

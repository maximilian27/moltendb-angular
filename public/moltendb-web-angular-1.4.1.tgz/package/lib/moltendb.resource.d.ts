import { Signal } from '@angular/core';
import { MoltenDbClient } from '@moltendb-web/query';
export interface MoltenDbResource<T> {
    value: Signal<T | undefined>;
    isLoading: Signal<boolean>;
    error: Signal<any | null>;
}
export declare function moltenDbResource<T>(collection: string, queryFn: (collection: ReturnType<MoltenDbClient['collection']>, client: MoltenDbClient) => Promise<T>): MoltenDbResource<T>;

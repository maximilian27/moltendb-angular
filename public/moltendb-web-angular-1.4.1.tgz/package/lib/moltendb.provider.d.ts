import { EnvironmentProviders, InjectionToken } from '@angular/core';
import { MoltenDbOptions } from '@moltendb-web/core';
export interface AngularMoltenDbOptions extends MoltenDbOptions {
    name: string;
}
export declare const MOLTEN_CONFIG: InjectionToken<AngularMoltenDbOptions>;
export declare function provideMoltenDb(config: AngularMoltenDbOptions): EnvironmentProviders;

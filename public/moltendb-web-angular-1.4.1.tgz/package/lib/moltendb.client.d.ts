import { MoltenDbClient } from '@moltendb-web/query';
/**
 * Functional injection hook to access the MoltenDb Query Client.
 * Removes the need to manually inject MoltenDbService in components.
 */
export declare function moltendbClient(): MoltenDbClient;

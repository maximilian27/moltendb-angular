import { MoltenDb } from '@moltendb-web/core';
import { MoltenDbClient } from '@moltendb-web/query';
import * as i0 from "@angular/core";
export declare class MoltenDbService {
    db: MoltenDb;
    client: MoltenDbClient;
    isReady: import("@angular/core").WritableSignal<boolean>;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<MoltenDbService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MoltenDbService>;
}

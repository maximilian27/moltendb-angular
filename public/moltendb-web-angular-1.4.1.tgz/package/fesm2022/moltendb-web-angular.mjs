import * as i0 from '@angular/core';
import { InjectionToken, makeEnvironmentProviders, signal, inject, Injectable, untracked, effect } from '@angular/core';
import { MoltenDb } from '@moltendb-web/core';
import { MoltenDbClient } from '@moltendb-web/query';

const MOLTEN_CONFIG = new InjectionToken('MOLTEN_CONFIG');
function provideMoltenDb(config) {
    return makeEnvironmentProviders([
        { provide: MOLTEN_CONFIG, useValue: config }
    ]);
}

class MoltenDbService {
    db;
    client;
    // A Signal components can watch to know when WASM is booted and Leader Election is done
    isReady = signal(false);
    constructor() {
        // 🚀 Modern Angular Injection (No constructor decorators needed!)
        const config = inject(MOLTEN_CONFIG);
        this.db = new MoltenDb(config.name, config);
        this.client = new MoltenDbClient(this.db);
        // Boot the engine and update the signal when done
        this.db.init().then(() => {
            this.isReady.set(true);
        }).catch(err => {
            console.error('[MoltenDb] Failed to initialize', err);
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MoltenDbService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MoltenDbService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MoltenDbService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [] });

function moltenDbResource(collection, 
//  Automatically infer the return type of .collection()
queryFn) {
    const molten = inject(MoltenDbService);
    const value = signal(undefined);
    const isLoading = signal(false);
    const error = signal(null);
    const fetchData = async () => {
        untracked(() => isLoading.set(true));
        try {
            // ⚡ Pre-bind the collection and pass it in!
            const result = await queryFn(molten.client.collection(collection), molten.client);
            value.set(result);
            error.set(null);
        }
        catch (err) {
            if (err.message?.includes('404')) {
                value.set([]);
                error.set(null);
            }
            else {
                error.set(err);
            }
        }
        finally {
            isLoading.set(false);
        }
    };
    effect((onCleanup) => {
        if (!molten.isReady())
            return;
        fetchData();
        const unsubscribe = molten.db.subscribe((evt) => {
            if (evt.collection === collection)
                fetchData();
        });
        onCleanup(() => unsubscribe());
    });
    return {
        value: value.asReadonly(),
        isLoading: isLoading.asReadonly(),
        error: error.asReadonly()
    };
}

/**
 * Functional injection hook to access the MoltenDb Query Client.
 * Removes the need to manually inject MoltenDbService in components.
 */
function moltendbClient() {
    return inject(MoltenDbService).client;
}

/*
 * Public API Surface of @moltendb-web/angular
 */

/**
 * Generated bundle index. Do not edit.
 */

export { MOLTEN_CONFIG, moltenDbResource, moltendbClient, provideMoltenDb };
//# sourceMappingURL=moltendb-web-angular.mjs.map
